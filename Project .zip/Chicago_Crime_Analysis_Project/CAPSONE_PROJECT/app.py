from pathlib import Path
from flask import Flask, jsonify, render_template, request
from sqlalchemy import Float, Integer, String, create_engine, select
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker

app = Flask(__name__)

# 1. Connect to crime_database.db in the project root
BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "crime_database.db"
if not DB_PATH.exists():
    DB_PATH = BASE_DIR.parent / "crime_database.db"

engine = create_engine(f"sqlite:///{DB_PATH}")
SessionLocal = sessionmaker(bind=engine)


# 2. Define the city_community table model
class Base(DeclarativeBase):
    pass


class CityCommunity(Base):
    __tablename__ = "city_community"

    community_code: Mapped[int] = mapped_column(Integer, primary_key=True)
    community_name: Mapped[str | None] = mapped_column(String)
    population: Mapped[int | None] = mapped_column(Integer)
    area_sqmile: Mapped[float | None] = mapped_column(Float)
    area_sqkm: Mapped[float | None] = mapped_column(Float)
    density_per_sqmi: Mapped[float | None] = mapped_column(Float)
    density_per_sqkm: Mapped[float | None] = mapped_column(Float)

    def to_dict(self):
        return {
            "community_code": self.community_code,
            "community_name": self.community_name,
            "population": self.population,
            "area_sqmile": self.area_sqmile,
            "area_sqkm": self.area_sqkm,
            "density_per_sqmi": self.density_per_sqmi,
            "density_per_sqkm": self.density_per_sqkm,
        }


# 3. HTML Page Routes
@app.route("/")
def dashboard():
    return render_template("dashboard.html")


@app.route("/crud")
def crud_page():
    return render_template("crud.html")


# 4. CRUD API Routes (GET, POST, PUT, PATCH, DELETE)

# READ all records
@app.route("/api/communities", methods=["GET"])
def get_communities():
    with SessionLocal() as session:
        rows = session.scalars(select(CityCommunity).order_by(CityCommunity.community_code)).all()
        return jsonify([row.to_dict() for row in rows]), 200


# CREATE a new record (POST)
@app.route("/api/communities", methods=["POST"])
def add_community():
    data = request.get_json()
    code = int(data["community_code"])

    with SessionLocal() as session:
        if session.get(CityCommunity, code):
            return jsonify({"message": "Community code already exists!"}), 409

        new_city = CityCommunity(
            community_code=code,
            community_name=data.get("community_name"),
            population=int(data["population"]) if data.get("population") else None,
            area_sqmile=float(data["area_sqmile"]) if data.get("area_sqmile") else None,
            area_sqkm=float(data["area_sqkm"]) if data.get("area_sqkm") else None,
            density_per_sqmi=float(data["density_per_sqmi"]) if data.get("density_per_sqmi") else None,
            density_per_sqkm=float(data["density_per_sqkm"]) if data.get("density_per_sqkm") else None,
        )
        session.add(new_city)
        session.commit()
        return jsonify({"message": "Community added successfully!"}), 201


# FULL UPDATE a record (PUT)
@app.route("/api/communities/<int:code>", methods=["PUT"])
def update_community(code):
    data = request.get_json()

    with SessionLocal() as session:
        city = session.get(CityCommunity, code)
        if not city:
            return jsonify({"message": "Community not found!"}), 404

        city.community_name = data.get("community_name")
        city.population = int(data["population"]) if data.get("population") else None
        city.area_sqmile = float(data["area_sqmile"]) if data.get("area_sqmile") else None
        city.area_sqkm = float(data["area_sqkm"]) if data.get("area_sqkm") else None
        city.density_per_sqmi = float(data["density_per_sqmi"]) if data.get("density_per_sqmi") else None
        city.density_per_sqkm = float(data["density_per_sqkm"]) if data.get("density_per_sqkm") else None

        session.commit()
        return jsonify({"message": "Community replaced successfully!"}), 200


# PARTIAL UPDATE a record (PATCH)
@app.route("/api/communities/<int:code>", methods=["PATCH"])
def patch_community(code):
    data = request.get_json()

    with SessionLocal() as session:
        city = session.get(CityCommunity, code)
        if not city:
            return jsonify({"message": "Community not found!"}), 404

        if data.get("community_name"):
            city.community_name = data["community_name"]
        if data.get("population"):
            city.population = int(data["population"])
        if data.get("area_sqmile"):
            city.area_sqmile = float(data["area_sqmile"])
        if data.get("area_sqkm"):
            city.area_sqkm = float(data["area_sqkm"])
        if data.get("density_per_sqmi"):
            city.density_per_sqmi = float(data["density_per_sqmi"])
        if data.get("density_per_sqkm"):
            city.density_per_sqkm = float(data["density_per_sqkm"])

        session.commit()
        return jsonify({"message": "Community updated successfully!"}), 200


# DELETE a record (DELETE)
@app.route("/api/communities/<int:code>", methods=["DELETE"])
def delete_community(code):
    with SessionLocal() as session:
        city = session.get(CityCommunity, code)
        if not city:
            return jsonify({"message": "Community not found!"}), 404

        session.delete(city)
        session.commit()
        return jsonify({"message": f"Community {code} deleted!"}), 200


if __name__ == "__main__":
    app.run(debug=True)